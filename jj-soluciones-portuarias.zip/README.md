# JJ Soluciones Portuarias

Proyecto base para la aplicación web del sector agroportuario.